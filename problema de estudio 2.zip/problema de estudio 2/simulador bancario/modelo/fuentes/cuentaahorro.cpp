#include "..\encabezados\cuentaahorro.h"

CCuentaDeAhorro::CCuentaDeAhorro(void)
{
}

CCuentaDeAhorro::CCuentaDeAhorro(double pSaldo, double pInteresMensual)
{
}

double CCuentaDeAhorro::darInteresMensual(void)
{
	return 0.0;
}

double CCuentaDeAhorro::darSaldo(void)
{
	return 0.0;
}

void CCuentaDeAhorro::consignarMonto(double pMonto)
{
}

void CCuentaDeAhorro::retirarMonto(double pMonto)
{
}

void CCuentaDeAhorro::actualizarSaldoPorMes(void)
{
}
