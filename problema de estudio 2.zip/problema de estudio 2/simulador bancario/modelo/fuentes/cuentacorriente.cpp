#include "..\encabezados\cuentacorriente.h"

Ccuentacorriente::Ccuentacorriente(double pSaldo)
{
}

double Ccuentacorriente::darsaldo(void)
{
	return 0.0;
}

void Ccuentacorriente::consignarmonto(double pMonto)
{
}

void Ccuentacorriente::retirarmonto(double pMonto)
{
}
