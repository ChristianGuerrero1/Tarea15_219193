#include "..\encabezados\cuentacdt.h"

CCuentaCDT::CCuentaCDT(void)
{
}

CCuentaCDT::CCuentaCDT(double pMontoInvertido, double pInteresMensual, int pMesApertura)
{
}

double CCuentaCDT::darInteresMensual(void)
{
	return 0.0;
}

double CCuentaCDT::calcularValorPresente(int pMesActual)
{
	return 0.0;
}

void CCuentaCDT::invertir(double pMonto, double pInteresMensual, int pMesApertura)
{
}

double CCuentaCDT::cerrarCuentaCDT(int pMesCierre)
{
	return 0.0;
}
